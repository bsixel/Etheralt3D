package gui;

import org.lwjgl.util.vector.Vector2f;

public class GUITexture {
	
	//Booleans
	boolean renderedThirdPerson;
	
	//Numbers
	private int texture;
	private Vector2f position;
	private Vector2f scale;
	
	public GUITexture(int texture, Vector2f position, Vector2f scale, boolean renderedThirdPerson) {
		
		this.texture = texture;
		this.position = position;
		this.scale = scale;
		this.renderedThirdPerson = renderedThirdPerson;
		
	}

	public int getTexture() {
		return texture;
	}

	public Vector2f getPosition() {
		return position;
	}

	public Vector2f getScale() {
		return scale;
	}
	
}
