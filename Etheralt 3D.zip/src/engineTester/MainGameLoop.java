package engineTester;

import entities.Camera;
import entities.Entity;
import entities.Light;
import entities.Player;
import gui.GUIRenderer;
import gui.GUITexture;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import models.RawModel;
import models.TexturedModel;
import objConverter.ModelData;
import objConverter.OBJFileLoader;

import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import renderEngine.DisplayHandler;
import renderEngine.FinalRenderer;
import renderEngine.Loader;
import terrainGens.Terrain;
import textures.ModelTexture;
import textures.TerrainTexture;
import textures.TerrainTexturePack;
import tools.MousePicker;

public class MainGameLoop {
	
	public static boolean paused;
	public static boolean pausedTime;

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		
		DisplayHandler.createDisplay();
		
		Loader loader = new Loader();
		
		//Master ID List
		
		
		//GUI Elements
		//GUITexture emblem = new GUITexture(loader.loadTexture("emblem"), new Vector2f(-0.9f, 0.8f), new Vector2f(128 / (float) (DisplayHandler.getRenderWidth()), 128 / (float) (DisplayHandler.getRenderHeight())), true);
		GUITexture cursor = new GUITexture(loader.loadTexture("pointer"), new Vector2f(0f, 0f), new Vector2f(16 / (float) (DisplayHandler.getRenderWidth()), 16 / (float) (DisplayHandler.getRenderHeight())), false);
		
		//Lights
		Light sun = new Light(new Vector3f(2000, 2000, 3000), new Vector3f(0.01f, 0.01f, 0.01f));
		
		//Derp Lamp
		ModelData derpLampData = OBJFileLoader.loadOBJ("derpLamp");
		RawModel derpLampModel = loader.loadToVAO(derpLampData.getVertices(), derpLampData.getTextureCoords(), derpLampData.getNormals(), derpLampData.getIndices(), derpLampData.getVertexList());
		ModelTexture derpLampTexture = new ModelTexture(loader.loadTexture("derpLamp"));
		TexturedModel texturedDerpLamp = new TexturedModel(derpLampModel, derpLampTexture);
		derpLampTexture.setReflectivity(1);
		derpLampTexture.setShineDamper(7);
		
		//Dragon
		ModelData dragonData = OBJFileLoader.loadOBJ("dragon");
		RawModel dragonModel = loader.loadToVAO(dragonData.getVertices(), dragonData.getTextureCoords(), dragonData.getNormals(), dragonData.getIndices(), dragonData.getVertexList());
		TexturedModel texturedDragon = new TexturedModel(dragonModel, new ModelTexture(loader.loadTexture("BlueThing")));
		ModelTexture dragonTexture = texturedDragon.getTexture();
		dragonTexture.setShineDamper(10);
		dragonTexture.setReflectivity(1);
		
		//Sample Human
		ModelData humanData = OBJFileLoader.loadOBJ("human1");
		RawModel humanModel = loader.loadToVAO(humanData.getVertices(), humanData.getTextureCoords(), humanData.getNormals(), humanData.getIndices(), humanData.getVertexList());
		TexturedModel humanTexturedModel = new TexturedModel(humanModel, new ModelTexture(loader.loadTexture("human1Texture")));
		humanTexturedModel.getTexture().setHasTransparency(true);
		humanTexturedModel.getTexture().setUseFakeLighting(true);
		
		//Initialize Entities
		Entity dragon = new Entity(texturedDragon, new Vector3f(0, 0, -25), 0, 0, 0, 5, true);
		Entity testHuman = new Entity(humanTexturedModel, new Vector3f(0, 0, 0), 0, 0, 0, 1.5f, true);
		
		//Sub-TerrainThings: Terrain Itself
		TerrainTexture backgroundTexture = new TerrainTexture(loader.loadTexture("grassy4"));
		TerrainTexture rTexture = new TerrainTexture(loader.loadTexture("mud"));
		TerrainTexture gTexture = new TerrainTexture(loader.loadTexture("grassFlowers"));
		TerrainTexture bTexture = new TerrainTexture(loader.loadTexture("path"));
		
		TerrainTexturePack texturePack1 = new TerrainTexturePack(backgroundTexture, rTexture, gTexture, bTexture);
		TerrainTexture blendMap = new TerrainTexture(loader.loadTexture("blendMap"));
		
		//Sub-Terrain Things: Grass n stuff
		ModelData grassData = OBJFileLoader.loadOBJ("grassModel");
		RawModel grassModel = loader.loadToVAO(grassData.getVertices(), grassData.getTextureCoords(), grassData.getNormals(), grassData.getIndices());
		TexturedModel grassTextureModel = new TexturedModel(grassModel, new ModelTexture(loader.loadTexture("tallGrass")));
		grassTextureModel.getTexture().setHasTransparency(true);
		grassTextureModel.getTexture().setUseFakeLighting(true);
		
		ModelData fernData = OBJFileLoader.loadOBJ("fern");
		ModelTexture fernTextureAtlas = new ModelTexture(loader.loadTexture("fern"));
		RawModel fernModel = loader.loadToVAO(fernData.getVertices(), fernData.getTextureCoords(), fernData.getNormals(), fernData.getIndices());
		TexturedModel fernTextureModel = new TexturedModel(fernModel, fernTextureAtlas);
		fernTextureAtlas.setNumberOfRows(2);
		fernTextureModel.getTexture().setHasTransparency(true);
		fernTextureModel.getTexture().setUseFakeLighting(true);
		
		ModelData genOak1Data = OBJFileLoader.loadOBJ("genOak1");
		RawModel genOak1Model = loader.loadToVAO(genOak1Data.getVertices(), genOak1Data.getTextureCoords(), genOak1Data.getNormals(), genOak1Data.getIndices());
		TexturedModel treeTextureModel = new TexturedModel(genOak1Model, new ModelTexture(loader.loadTexture("genOakWhole")));
		
		//Lists (entities, terrains, etc.)
		List<Entity> entitiesToRender = new ArrayList<Entity>();
		List<Terrain> terrainsToRender = new ArrayList<Terrain>();
		List<GUITexture> GUIElements = new ArrayList<GUITexture>();
		List<Light> lights = new ArrayList<Light>();
		List<Player> players = new ArrayList<Player>();
		List<Camera> cameras = new ArrayList<Camera>();
		
		//Renderers
		FinalRenderer renderer = new FinalRenderer(loader);
		GUIRenderer guiRenderer = new GUIRenderer(loader);
		
		//Adding Spare Entities
		entitiesToRender.add(testHuman);
		entitiesToRender.add(dragon);
		
		//Players
		//1
		Player player1 = new Player(renderer, humanTexturedModel, new Vector3f(10, 0, 10), 0, 0, 0, 1.5f, 3, players, true, 1);
		players.add(player1);
		Camera camera1 = new Camera(player1, "Test Player1", new Vector3f(0, 10.3f, 0), 0f, 0f, 0f);
		cameras.add(camera1);
		//2
		Player player2 = new Player(renderer, humanTexturedModel, new Vector3f(100, 0, 0), 0, 0, 0, 1, 5, players, false, 2);
		players.add(player2);
		Camera camera2 = new Camera(player2, "Test Player 2", new Vector3f(100, 10.3f, 0), 0f, 0f, 0f);
		cameras.add(camera2);
		//3
		Player player3 = new Player(renderer, humanTexturedModel, new Vector3f(-100, 50, -100), 0, 0, 0, 1, 5, players, false, 3);
		players.add(player3);
		Camera camera3 = new Camera(player3, "Test Player 3", new Vector3f(-100, 50f, 100), 0f, 0f, 0f);
		cameras.add(camera3);
		
		//Mouse Picker
		MousePicker mousePicker1 = new MousePicker(Camera.currentCamera(cameras), renderer.getProjectionMatrix(), terrainsToRender);
		
		GUIElements.add(cursor);
		
		Random generationRandom = new Random();
		Random lightColorRandom = new Random();
		
		//Terrains
		for (int i = -5; i < 5; i ++) {
			for (int j = -5; j < 5; j ++) {
				terrainsToRender.add(new Terrain(i, j, loader, texturePack1, blendMap, "heightmap"));
			}
		}
		
		for (Entity entity:entitiesToRender) {
			entity.getCollisionShell().generateCorners(entity);
		}
		
		for (Player player:players) {
			player.getCollisionShell().generateCorners(player);
		}
		
		for (Vector3f pos:player1.getCollisionShell().getWidePassBox()) {
			
			entitiesToRender.add(new Entity(texturedDerpLamp, pos, 0, 0, 0, 1, true));
			
		}
		
		//Lights
		lights.add(sun);
		
		for (int i = 0; i < 10; i++) {
			
			float x = generationRandom.nextFloat() * 800;
			float z = generationRandom.nextFloat() * 800;
			float y = (float) (10 + Terrain.getCurrentTerrain(terrainsToRender, x, z).getHeightOfTerrain(x, z));
			entitiesToRender.add(new Entity(texturedDerpLamp, new Vector3f(x, y - 10, z), 0, 0, 0, 5, true));
			lights.add(new Light(new Vector3f(x, y, z), new Vector3f(lightColorRandom.nextFloat() * 4, lightColorRandom.nextFloat() * 4, lightColorRandom.nextFloat() * 4), new Vector3f(1f, 0.01f, 0.002f)));
			
		}
		
		//Flora
		for (int i = 0; i < 5000; i++) {
			
			float x = generationRandom.nextFloat() * 800;
			float z = generationRandom.nextFloat() * 800;
			float y = Terrain.getCurrentTerrain(terrainsToRender, x, z).getHeightOfTerrain(x, z);
			entitiesToRender.add(new Entity(grassTextureModel, new Vector3f(x, y, z), 0, 0, 0, 5f, false));
			entitiesToRender.add(new Entity(grassTextureModel, new Vector3f(-x, Terrain.getCurrentTerrain(terrainsToRender, -x, -z).getHeightOfTerrain(-x, -z), -z), 0, 0, 0, 5f, false));
			entitiesToRender.add(new Entity(grassTextureModel, new Vector3f(-x, Terrain.getCurrentTerrain(terrainsToRender, -x, z).getHeightOfTerrain(-x, z), z), 0, 0, 0, 5f, false));
			entitiesToRender.add(new Entity(grassTextureModel, new Vector3f(x, Terrain.getCurrentTerrain(terrainsToRender, x, -z).getHeightOfTerrain(x, -z), -z), 0, 0, 0, 5f, false));
			
		}
		
		for (int i = 0; i < 5000; i++) {
			
			float x = generationRandom.nextFloat() * 800;
			float z = generationRandom.nextFloat() * 800;
			float y = Terrain.getCurrentTerrain(terrainsToRender, x, z).getHeightOfTerrain(x, z);
			entitiesToRender.add(new Entity(fernTextureModel, generationRandom.nextInt(4), new Vector3f(x, y, z), 0, 0, 0, 1f, false));
			entitiesToRender.add(new Entity(fernTextureModel, generationRandom.nextInt(4), new Vector3f(-x, Terrain.getCurrentTerrain(terrainsToRender, -x, -z).getHeightOfTerrain(-x, -z), -z), 0, 0, 0, 1f, false));
			entitiesToRender.add(new Entity(fernTextureModel, generationRandom.nextInt(4), new Vector3f(-x, Terrain.getCurrentTerrain(terrainsToRender, -x, z).getHeightOfTerrain(-x, z), z), 0, 0, 0, 1f, false));
			entitiesToRender.add(new Entity(fernTextureModel, generationRandom.nextInt(4), new Vector3f(x, Terrain.getCurrentTerrain(terrainsToRender, x, -z).getHeightOfTerrain(x, -z), -z), 0, 0, 0, 1f, false));
			
		}
		
		for (int i = 0; i < 40; i++) {
			
			float x = generationRandom.nextFloat() * 800;
			float z = generationRandom.nextFloat() * 800;
			float y = Terrain.getCurrentTerrain(terrainsToRender, x, z).getHeightOfTerrain(x, z);
			entitiesToRender.add(new Entity(treeTextureModel, new Vector3f(x, y, z), 0, 0, 0, 7f, true));
			entitiesToRender.add(new Entity(treeTextureModel, new Vector3f(-x, Terrain.getCurrentTerrain(terrainsToRender, -x, -z).getHeightOfTerrain(-x, -z), -z), 0, 0, 0, 7f, true));
			entitiesToRender.add(new Entity(treeTextureModel, new Vector3f(x, Terrain.getCurrentTerrain(terrainsToRender, x, -z).getHeightOfTerrain(x, -z), -z), 0, 0, 0, 7f, true));
			entitiesToRender.add(new Entity(treeTextureModel, new Vector3f(-x, Terrain.getCurrentTerrain(terrainsToRender, -x, z).getHeightOfTerrain(-x, z), z), 0, 0, 0, 7f, true));
			
		}
		
		//On Tick Things
		while (!Display.isCloseRequested()) {
			
			player3.increaseRotation(0, 0.1f, 0);
			
			Player.activePlayer(players).move(Terrain.getCurrentTerrain(terrainsToRender, player1.getPosition().x, player1.getPosition().z));
			
			if (Player.activePlayer(players).getMovementMode() != "flyCam") {
				Player.activePlayer(players).upwardVelocity += Player.activePlayer(players).gravity * Player.activePlayer(players).tick();
				Player.activePlayer(players).increasePosition(0, Player.activePlayer(players).upwardVelocity * Player.activePlayer(players).tick(), 0);
			}
			
			Camera.currentCamera(cameras).updateCameraPos();
			
			mousePicker1.update();
			//Vector3f terrainPoint1 = mousePicker1.getCurrentTerrainPoint();
			/*if (terrainPoint1 != null) {
				testHuman.setPosition(terrainPoint1);
			}*/
			
			sun.updateSunPosition(renderer.getSkyboxRenderer().time, Player.activePlayer(players));
			
			for (Terrain terrain:terrainsToRender) {
					renderer.processTerrain(terrain);
			}
			
			for (Player player:players) {
				if (player.isThirdPerson) {
					renderer.processEntity(player);
				}
			}
			
			renderer.render(lights, Camera.currentCamera(cameras));
			
			guiRenderer.render(GUIElements, Player.activePlayer(players));
			
			for (Entity grass:entitiesToRender) {
				renderer.processEntity(grass);
			}
			
			DisplayHandler.updateDisplay();
			
		}
		
		guiRenderer.cleaner();
		renderer.cleaner();
		loader.cleaner();
		
		DisplayHandler.closeDisplay();
		
	}

}