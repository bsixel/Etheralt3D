package entities;

import static java.lang.Math.cos;
import static java.lang.Math.sin;
import static java.lang.Math.toRadians;

import java.util.List;

import models.TexturedModel;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import renderEngine.DisplayHandler;
import renderEngine.FinalRenderer;
import terrainGens.Terrain;
import engineTester.MainGameLoop;

public class Player extends Entity {

	public Player(FinalRenderer renderer, TexturedModel model,
			Vector3f position, float rotX, float rotY, float rotZ, float scale, int playerType, List<Player> players, boolean activePlayer, int playerID) {
		super(model, position, rotX, rotY, rotZ, scale, true);
		this.players = players;
		this.renderer = renderer;
		this.playerType = playerType;
		this.activePlayer = activePlayer;
		this.playerID = playerID;

	}

	// Booleans
	boolean activePlayer;
	public boolean paused = false;
	boolean sprinting = false;
	public boolean isThirdPerson = false;
	public boolean isAirborne = false;
	boolean controlPressed;
	boolean turbo = false;

	// Numbers
	public int playerID;
	public int playerType;
	float pitch = 0;
	float yaw = 0;
	float roll = 0;
	private float halfWidth = Display.getWidth() / 2;
	private float halfHeight = Display.getHeight() / 2;
	float sensitivity = 0.5f;
	float speed = 25f;
	private int movementModeNumber = 0;
	int dWheel = Mouse.getDWheel();
	private float sprintMult = (float) 2.5;
	int currentCamNum = 0;
	public float thirdPersonDist = 50;
	public float gravity = -100;
	public float jumpStrength = 50;
	public float upwardVelocity = 0;
	float distance;
	float dx;
	float dz;
	float sdx;
	float sdz;

	//Vectors
	private Vector3f velocity = new Vector3f();
	private Vector3f deadVector = new Vector3f(); 

	// Strings / Objects
	String cameraName;
	String movementMode = "normal";
	String[] movementModes = { "normal", "flyCam" };
	Camera currentCamera;
	public FinalRenderer renderer;
	private Terrain currentTerrain;

	//Lists
	List<Player> players;

	public static Player activePlayer(List<Player> players) {
		Player currentPlayer = null;
		for (Player player:players) {
			if (player.activePlayer) {
				currentPlayer = player;
			}
		}
		return currentPlayer;
	}

	public boolean isPaused() {
		return paused;
	}

	public float maxLook() {

		if (movementMode == "flyCam" || playerType == 4) {
			return 999999999;
		} else
			return 90;

	}

	public float tick() {
		return DisplayHandler.getFrameTimeSeconds();
	}

	public void setThirdPersonDist(int change) {
		this.thirdPersonDist -= change / 10;
	}

	public String getMovementMode() {
		return movementMode;
	}
	
	public void jump(Float jumpMult) {
		if (!isAirborne) {
			this.velocity.y += jumpStrength * jumpMult;
			isAirborne = !isAirborne;
		}
	}

	public float movementSpeed() {
		if (turbo) {
			return speed * 5;
		} else return speed;
	}

	public Player nextPlayer() {
		Player nextPlayer;
		if (this.playerID < players.size()) {
			nextPlayer = players.get(this.playerID);
		} else
			nextPlayer = players.get(0);
		return nextPlayer;
	}

	public void increaseRotation(float pitchChange, float yawChange, float rollChange) {

		pitch += pitchChange;
		yaw += yawChange;

	}

	private float terrainHeight(Terrain terrain) {

		if (terrain == null) {
			return 0;
		} else return terrain.getHeightOfTerrain(super.getPosition().x, super.getPosition().z);

	}
	
	public void checkCollision() {
		
		Vector3f.add(super.getPosition(), this.velocity, super.getPosition());
		this.velocity.set(deadVector);
		
	}
	
	public void move(Terrain terrain) {

		this.currentTerrain = terrain;
		this.getCollisionShell().generateCorners(this);
		checkInputs();
		checkCollision();
		
	}

	public float angleVers() {
		float a = 0;
		if (this.isThirdPerson == true) {
			a = -(this.getRotY());
		} else if (this.isThirdPerson == false) {
			a = this.yaw;
		}
		return a;
	}

	public float sAngleVers() {
		float a = 0;
		if (this.isThirdPerson == true) {
			a = -(super.getRotY() - 90);
		} else if (this.isThirdPerson == false) {
			a = this.yaw + 90;
		}
		return a;
	}

	public void getOtherKeys() {

		while (Keyboard.next()) {

			if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
				MainGameLoop.paused = !MainGameLoop.paused;
				Mouse.setCursorPosition((int) halfWidth, (int) halfHeight);
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_DECIMAL)) {
				MainGameLoop.pausedTime = !MainGameLoop.pausedTime;
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_M)) {
				if (this.playerType ==  3) {
					movementMode = movementModes[movementModeNumber];
					if (movementModeNumber + 1 >= movementModes.length) {
						movementModeNumber = 0;
					} else
						movementModeNumber += 1;
				}
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_C)) {
				if (this.playerType == 2 || this.playerType == 3) {
					isThirdPerson = !isThirdPerson;
				}
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_ADD)) {
				renderer.getSkyboxRenderer().time += 1000;
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_SUBTRACT)) {
				renderer.getSkyboxRenderer().time -= 1000;
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_7)) {
				activePlayer = !activePlayer;
				nextPlayer().activePlayer = true;
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
				turbo = !turbo;
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_F11)) {
				DisplayHandler.setDisplayMode(Display.getDesktopDisplayMode().getWidth(), Display.getDesktopDisplayMode().getHeight(), true);
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_F12)) {
				DisplayHandler.setDisplayMode(Display.getDesktopDisplayMode().getWidth(), Display.getDesktopDisplayMode().getHeight(), false);
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_UP)) {
				this.setScale(this.getScale() + 0.1f);
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_DOWN)) {
				this.setScale(this.getScale() - 0.1f);
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_T)) {
				this.setPosition(new Vector3f(0, 0, 0));
			}
			if (Keyboard.isKeyDown(Keyboard.KEY_H)) {
				System.out.println("X-Angle: " + this.pitch);
				System.out.println("Y-Angle: " + this.yaw);
				System.out.println("Z-Angle: " + this.roll);
				System.out.println("RotY: " + this.getRotY());
				System.out.println("RotX: " + this.getRotX());
				System.out.println("FOV: " + renderer.FOV);
				System.out.println("TPD: " + this.thirdPersonDist);
				System.out.println("Turbo: " + turbo);
				System.out.println("Fullscreen:" + DisplayHandler.fullscreen);
				System.out.println("Render Width:" + DisplayHandler.getRenderWidth());
				System.out.println("Render Height:" + DisplayHandler.getRenderHeight());
				System.out.println(activePlayer);
				System.out.println(this.playerID);
				System.out.println("X-Pos:" + super.getPosition().x);
				System.out.println("Y-Pos:" + super.getPosition().y);
				System.out.println("Z-Pos:" + super.getPosition().z);
			}

		}

	}

	public void checkInputs() {
		
		getOtherKeys();
		
		this.distance = movementSpeed() * DisplayHandler.getFrameTimeSeconds();
		this.dx = (float) (sin(toRadians(angleVers())) * this.distance);
		this.dz = (float) (cos(toRadians(angleVers())) * this.distance);
		this.sdx = (float) (sin(toRadians(sAngleVers())) * this.distance);
		this.sdz = (float) (cos(toRadians(sAngleVers())) * this.distance);

		if (movementMode == "flyCam") {

			float dy = (float) -(cos(toRadians(pitch + 90)) * this.distance);

			// Ascend or Descend
			if (Keyboard.isKeyDown(Keyboard.KEY_E)) {
				if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
					this.velocity.y += sprintMult * 2 * this.distance;
				} else {
					this.velocity.y += this.distance;
				}
			} else if (Keyboard.isKeyDown(Keyboard.KEY_Q)) {
				if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
					this.velocity.y += sprintMult * 2 * -this.distance;
				} else {
					this.velocity.y += -this.distance;
				}
			} else {
				this.velocity.y += 0;
			}
			
			// Front and Back
			if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
				if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
					this.velocity.z -= sprintMult * 2 * -dz;
					this.velocity.x -= sprintMult * 2 * dx;
					this.velocity.y -= sprintMult * 2 * dy;
				} else {
					this.velocity.z -= -dz;
					this.velocity.x -= dx;
					this.velocity.y -= dy;
				}
			} else if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
				if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
					this.velocity.z -= sprintMult * 2 * dz;
					this.velocity.x -= sprintMult * 2 * -dx;
					this.velocity.y -= sprintMult * 2 * -dy;
				} else {
					this.velocity.z -= dz;
					this.velocity.x -= -dx;
					this.velocity.y -= -dy;
				}
			} else {
				this.velocity.z -= 0;
				this.velocity.x -= 0;
				this.velocity.y -= 0;
			}

		}

		//Jumping
		if (movementMode != "flyMode") {
			if (Keyboard.isKeyDown(Keyboard.KEY_SPACE)) {
				if (turbo) {
					jump(1.5f);
				} else {
					jump(1f);
				}
			}
		}

		// Front and Back
		if (playerType != 4 && playerType != 5) {
			if (Keyboard.isKeyDown(Keyboard.KEY_W)) {
				if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
					this.velocity.z -= sprintMult * -dz;
					this.velocity.x -= sprintMult * dx;
				} else {
					this.velocity.z -= -dz;
					this.velocity.x -= dx;
				}
			} else if (Keyboard.isKeyDown(Keyboard.KEY_S)) {
				if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT)) {
					this.velocity.z -= sprintMult * dz;
					this.velocity.x -= sprintMult * -dx;
				} else {
					this.velocity.z -= dz;
					this.velocity.x -= -dx;
				}
			} else {
				this.velocity.z -= 0;
				this.velocity.x -= 0;
			}
		}

		// Sideways
		if (playerType != 4 && playerType != 5) {
			if (Keyboard.isKeyDown(Keyboard.KEY_D)) {
				this.velocity.z -= -sdz;
				this.velocity.x -= sdx;
			}
			else if (Keyboard.isKeyDown(Keyboard.KEY_A)) {
				this.velocity.z -= sdz;
				this.velocity.x -= -sdx;
			}
		}

		Mouse.setGrabbed(!MainGameLoop.paused);

		if (!MainGameLoop.paused && playerType != 5) {

			if (isThirdPerson == false) {
				super.setRotY(-yaw);

				float maxLookUp = maxLook();
				float maxLookDown = -maxLook();
				float mouseDX = (Mouse.getX() - halfWidth) * sensitivity;
				float mouseDY = (Mouse.getY() - halfHeight) * sensitivity;
				if (yaw + mouseDX >= 360) {
					yaw = yaw + mouseDX - 360;
				} else if (yaw + mouseDX < 0) {
					yaw = 360 - yaw + mouseDX;
				} else {
					yaw += mouseDX;
				}
				if (pitch - mouseDY >= maxLookDown
						&& pitch - mouseDY <= maxLookUp) {
					pitch += -mouseDY;
				} else if (pitch - mouseDY < maxLookDown) {
					pitch = maxLookDown;
				} else if (pitch - mouseDY > maxLookUp) {
					pitch = maxLookUp;
				}

			}

			float terrainHeight = terrainHeight(this.currentTerrain);

			if (super.getPosition().y + this.velocity.y < terrainHeight) {
				this.velocity.y = 0;
				super.getPosition().y = terrainHeight;
				isAirborne = false;
			}

			if (isThirdPerson == true) {
				float mouseDX = (Mouse.getX() - halfWidth) * sensitivity;
				float mouseDY = (Mouse.getY() - halfHeight) * sensitivity;
				if (yaw + mouseDX >= 360) {
					yaw = yaw + mouseDX - 360;
				} else if (yaw + mouseDX < 0) {
					yaw = 360 - yaw + mouseDX;
				} else {
					yaw += mouseDX;
				}
				if (pitch - mouseDY >= 0 && pitch - mouseDY <= 30) {
					pitch += -mouseDY / 2;
				} else if (pitch - mouseDY < 0) {
					pitch = 0;
				} else if (pitch - mouseDY > 30) {
					pitch = 30;
				}
				super.setRotY(-yaw);
			}

			Mouse.setCursorPosition((int) halfWidth, (int) halfHeight);

		}

	}

}