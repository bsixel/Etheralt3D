package entities;

import static java.lang.Math.cos;
import static java.lang.Math.sin;

import java.util.List;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector3f;

import engineTester.MainGameLoop;
import tools.Maths;

public class Camera {

	// Booleans
	boolean paused = false;
	boolean sprinting = false;
	public boolean isFreeCam = false;
	boolean turbo = false;

	// Numbers
	private Vector3f position;
	private float pitch = 0;
	private float yaw = 0;
	private float roll = 0;
	private float halfWidth = Display.getWidth() / 2;
	private float halfHeight = Display.getHeight() / 2;
	float lastYaw, lastPitch = 0;
	private float distance;
	public int currentCamNum = 0;
	float thirdPersonDist = 50;
	float playerCameraAngle = 0;
	
	//Player
	private Player player;

	public Camera(Player player, String cameraName, Vector3f position,
			float pitch, float yaw, float roll) {

		this.cameraName = cameraName;
		this.position = player.getPosition();
		this.pitch = pitch;
		this.yaw = player.getRotY();
		this.roll = roll;
		this.player = player;

	}

	// Strings / Objects
	String cameraName;
	String movementMode = "normal";
	Camera currentCamera;
	
	public static Camera currentCamera(List<Camera> cameras) {
		Camera currentCamera = null;
		
		for (Camera camera:cameras) {
			if (camera.player.activePlayer) {
				currentCamera = camera;
			}
		}
		
		return currentCamera;
		
	}
	
	public float maxLook() {

		if (movementMode == "flyCam") {
			return 900000000;
		} else
			return 90;

	}

	public void calcPlayerCamAngle() {
		float angleChange = Mouse.getDX();
		playerCameraAngle -= angleChange;
	}
	
	public float calcHorizontalDist() {
		return (float) (thirdPersonDist * Math.cos(Math.toRadians(pitch)));
	}
	
	public float calcVerticalDist() {
		return (float) (thirdPersonDist * Math.sin(Math.toRadians(pitch)));
	}
	
	public void followPlayer() {
		
		Vector3f addedPos = new Vector3f((float) 0.005, (float) this.player.getHeight(),
				(float) 0);

		if (player.isThirdPerson == false) {

			this.position = Maths.addVector3f(addedPos, this.player.getPosition());
			this.yaw = this.player.yaw - 180;
			this.pitch = this.player.pitch;
			this.roll = this.player.roll;
			
		}

		if (this.player.isThirdPerson == true) {

			this.position = Maths
					.addVector3f(
							this.player.getPosition(),
							new Vector3f((float) (-this.player.thirdPersonDist / 2 * sin(Math.toRadians(this.player.getRotY()))) * player.getScale(),
									(float) (this.player.thirdPersonDist * sin(Math.toRadians(pitch))) + player.getHeight(),
									(float) (-this.player.thirdPersonDist / 2 * cos(Math.toRadians(this.player.getRotY())))  * player.getScale()));

			this.yaw = this.player.sAngleVers() - 270;
			this.pitch = this.player.pitch;

		}

		if (paused) {
			Mouse.setCursorPosition((int) halfWidth, (int) halfHeight);
		}

	}
	
	public void updateCameraPos() {
		
			if (!MainGameLoop.paused) {
				followPlayer();
			}
		
	}

	public boolean isPaused() {
		return paused;
	}

	public void setPaused(boolean paused) {
		this.paused = paused;
	}

	public float getHalfWidth() {
		return halfWidth;
	}

	public float getHalfHeight() {
		return halfHeight;
	}

	public float getLastYaw() {
		return lastYaw;
	}

	public float getLastPitch() {
		return lastPitch;
	}

	public float getDistance() {
		return distance;
	}

	public void setPosition(Vector3f position) {
		this.position = position;
	}

	public void setPitch(float pitch) {
		this.pitch = pitch;
	}

	public void setYaw(float yaw) {
		this.yaw = yaw;
	}

	public void setRoll(float roll) {
		this.roll = roll;
	}

	public String getCameraName() {
		return cameraName;
	}

	public Vector3f getPosition() {
		return position;
	}

	public float getPitch() {
		return pitch;
	}

	public float getYaw() {
		return yaw;
	}

	public float getRoll() {
		return roll;
	}

}