package tools;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import objConverter.Vertex;

import org.lwjgl.util.vector.Vector3f;

import entities.Entity;

public class CollisionChecker {
	
	private Vector3f bottomFrontLeft = new Vector3f();
	private Vector3f bottomFrontRight = new Vector3f();
	private Vector3f bottomBackLeft = new Vector3f();
	private Vector3f bottomBackRight = new Vector3f();
	private Vector3f topFrontLeft = new Vector3f();
	private Vector3f topFrontRight = new Vector3f();
	private Vector3f topBackLeft = new Vector3f();
	private Vector3f topBackRight = new Vector3f();
	
	Vector3f[] widePassBox = {bottomFrontLeft, bottomFrontRight, bottomBackLeft, bottomBackRight, topFrontLeft, topFrontRight, topBackLeft, topBackRight};
	List<Vertex> encompassedVertices;
	Entity entity;
	
	public void generateCorners(Entity entity) {
		
		this.entity = entity;
		this.encompassedVertices = entity.getModel().getRawModel().getVertices();
		
		List<Float> XFloats = new ArrayList<Float>();
		List<Float> YFloats = new ArrayList<Float>();
		List<Float> ZFloats = new ArrayList<Float>();
		
		for (Vertex vertex:encompassedVertices) {
			
			XFloats.add(vertex.getPosition().x * entity.getScale());
			YFloats.add(vertex.getPosition().y * entity.getScale());
			ZFloats.add(vertex.getPosition().z * entity.getScale());
			
		}
		
		Collections.sort(XFloats);
		Collections.sort(YFloats);
		Collections.sort(ZFloats);
		
		this.bottomFrontLeft.set(XFloats.get(0), YFloats.get(0), ZFloats.get(0));
		this.bottomFrontRight.set(XFloats.get(XFloats.size() - 1), YFloats.get(0), ZFloats.get(0));
		this.bottomBackLeft.set(XFloats.get(0), YFloats.get(0), ZFloats.get(ZFloats.size() - 1));
		this.bottomBackRight.set(XFloats.get(XFloats.size() - 1), YFloats.get(0), ZFloats.get(ZFloats.size() - 1));
		this.topFrontLeft.set(XFloats.get(0), YFloats.get(YFloats.size() - 1), ZFloats.get(0));
		this.topFrontRight.set(XFloats.get(XFloats.size() - 1), YFloats.get(YFloats.size() - 1), ZFloats.get(0));
		this.topBackLeft.set(XFloats.get(0), YFloats.get(YFloats.size() - 1), ZFloats.get(ZFloats.size() - 1));
		this.topBackRight.set(XFloats.get(XFloats.size() - 1), YFloats.get(YFloats.size() - 1), ZFloats.get(ZFloats.size() - 1));
		
	}
	
	public float getEntityHeight() {
		return this.topBackLeft.y;
	}
	
	public Vector3f[] getWidePassBox() {
		return this.widePassBox;
	}
	
}