package models;

import java.util.List;

import objConverter.Vertex;

import org.lwjgl.util.vector.Vector3f;

public class RawModel {

	private int vaoID;
	private int vertexCount;
	
	List<Vertex> vertices;
	List<Vector3f> normals;
	
	public RawModel(int vaoID, int vertexCount, List<Vertex> vertices) {

		this.vaoID = vaoID;
		this.vertexCount = vertexCount;
		this.vertices = vertices;

	}
	
	public RawModel(int vaoID, int vertexCount) {

		this.vaoID = vaoID;
		this.vertexCount = vertexCount;

	}

	public List<Vertex> getVertices() {

		return vertices;

	}

	public List<Vector3f> getNormals() {

		return normals;

	}

	public int getVaoID() {
		return vaoID;
	}

	public int getVertexCount() {
		return vertexCount;
	}

}